package br.com.jonfallenbr.rest_spring_rest_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestSpringRestJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestSpringRestJavaApplication.class, args);
	}

}
