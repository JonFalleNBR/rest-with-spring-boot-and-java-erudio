package br.com.jonfallenbr.rest_spring_rest_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSpringRestJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
